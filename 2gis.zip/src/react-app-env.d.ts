/// <reference types="react-scripts" />
/// <reference path="../node_modules/@2gis/mapgl/global.d.ts" />
