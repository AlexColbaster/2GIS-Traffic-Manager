# Getting Started with MapGL React App

-   `npm install` — install dependencies
-   `npm start` — start demo
